package org.bova.interview.functionpointer;

public class MyFunctionImpl implements MyFunction{

        public void fn(ListNode node) {
                System.out.println(node.getData());
        }
}
