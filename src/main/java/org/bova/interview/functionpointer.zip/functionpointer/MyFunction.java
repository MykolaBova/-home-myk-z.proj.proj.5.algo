package org.bova.interview.functionpointer;

@FunctionalInterface
public interface MyFunction {
        void fn(ListNode node);
}
